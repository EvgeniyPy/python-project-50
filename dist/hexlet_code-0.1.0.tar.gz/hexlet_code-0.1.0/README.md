### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/8e37176a227070261dcc/maintainability)](https://codeclimate.com/github/EvgeniyPy/python-project-50/maintainability)




[![Test Coverage](https://api.codeclimate.com/v1/badges/8e37176a227070261dcc/test_coverage)](https://codeclimate.com/github/EvgeniyPy/python-project-50/test_coverage)

[![Actions Status](https://github.com/EvgeniyPy/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/EvgeniyPy/python-project-50/actions)



[![asciicast](https://asciinema.org/a/C35EwmO2RzgCN9KdV0C65Qxwb.svg)](https://asciinema.org/a/C35EwmO2RzgCN9KdV0C65Qxwb)


[![asciicast](https://asciinema.org/a/l2E97DKpjnN7vs6dtMlmTodnP.svg)](https://asciinema.org/a/l2E97DKpjnN7vs6dtMlmTodnP)


[![asciicast](https://asciinema.org/a/uVf2vmwms8aLZtLTNO9TRb5FW.svg)](https://asciinema.org/a/uVf2vmwms8aLZtLTNO9TRb5FW)


[![asciicast](https://asciinema.org/a/G0MefoFjl2SyQp4uCEuVinFY6.svg)](https://asciinema.org/a/G0MefoFjl2SyQp4uCEuVinFY6)