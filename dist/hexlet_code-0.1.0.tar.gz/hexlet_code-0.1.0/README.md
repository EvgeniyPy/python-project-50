### Hexlet tests and linter status:
[![Actions Status](https://github.com/EvgeniyPy/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/EvgeniyPy/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/a057b2b847e97a9e27a9/maintainability)](https://codeclimate.com/github/EvgeniyPy/python-project-50/maintainability)


[![Test Coverage](https://api.codeclimate.com/v1/badges/a057b2b847e97a9e27a9/test_coverage)](https://codeclimate.com/github/EvgeniyPy/python-project-50/test_coverage)

[![Actions Status](https://github.com/EvgeniyPy/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/EvgeniyPy/python-project-50/actions)



[![asciicast](https://asciinema.org/a/C35EwmO2RzgCN9KdV0C65Qxwb.svg)](https://asciinema.org/a/C35EwmO2RzgCN9KdV0C65Qxwb)